// 题库配置
const questions = [
    {
        id: 1,
        title: "你觉得哪一侧脸整体看起来更「大」？",
        observation: "请看正面自然表情照片，重点看中下面部整体占位感，不是只看某一小块。这里的「大」，包括一侧更宽、一侧更鼓、一侧更有存在感、一侧下颌缘更外扩。",
        options: [
            { text: "左侧更大", value: "left_bigger" },
            { text: "右侧更大", value: "right_bigger" },
            { text: "两侧差不多或看不出", value: "similar" }
        ]
    },
    {
        id: 2,
        title: "你觉得哪一侧更「紧、硬、鼓」？",
        observation: "请用手轻摸两侧咬肌、脸颊和下颌缘，或者看照片。这里不是问哪边骨头高，而是问哪边更像更绷、更厚、更顶、更容易显得结实或发硬。",
        options: [
            { text: "左侧更明显", value: "left_tight" },
            { text: "右侧更明显", value: "right_tight" },
            { text: "不明显或说不清", value: "not_clear" }
        ]
    },
    {
        id: 3,
        title: "你觉得哪一侧更像「被拉偏」而不是「更厚」？",
        observation: "重点看一侧嘴角像被斜着拖走，一侧苹果肌更高更紧，一侧法令纹更深，一侧下颌线更绷更利，整张脸像沿一条斜线被拧过。",
        options: [
            { text: "左侧更像被拉偏", value: "left_pulled" },
            { text: "右侧更像被拉偏", value: "right_pulled" },
            { text: "没有这种感觉或不确定", value: "not_sure" }
        ]
    },
    {
        id: 4,
        title: "把头自然摆正后，左右差异会不会减轻？",
        observation: "不是刻意挺直，也不是抬头收下巴，只是把平时习惯歪向一边的头轻轻回到中立位，再看左右差异。",
        options: [
            { text: "明显减轻", value: "significantly_reduced" },
            { text: "有一点减轻", value: "slightly_reduced" },
            { text: "基本没变化", value: "no_change" },
            { text: "不确定", value: "uncertain" }
        ]
    },
    {
        id: 5,
        title: "平躺后，左右差异会不会减轻？",
        observation: "平躺时尽量不用高枕，不咬牙，不做表情，看脸部左右差异是否比站立时减轻。",
        options: [
            { text: "明显减轻", value: "significantly_reduced_lying" },
            { text: "有一点减轻", value: "slightly_reduced_lying" },
            { text: "基本没变化", value: "no_change_lying" },
            { text: "不确定", value: "uncertain_lying" }
        ]
    },
    {
        id: 6,
        title: "微笑或说话时，两边差异会不会更明显？",
        observation: "不要只看静态照。请看自己微笑、说话、露齿时，一侧口角是否更容易上去，一侧是否更慢，一侧是否明显更使不上劲或更漏。",
        options: [
            { text: "明显更明显", value: "significantly_more_obvious" },
            { text: "有一点更明显", value: "slightly_more_obvious" },
            { text: "差不多", value: "similar_dynamic" },
            { text: "不确定", value: "uncertain_dynamic" }
        ]
    },
    {
        id: 7,
        title: "你更像是哪一种情况？",
        observation: "A 类是一侧更厚、更硬、更鼓，像「肉多或出力多」；B 类是一侧更像被斜着拉偏，位置不对，不只是厚薄差。",
        options: [
            { text: "更像A厚硬鼓", value: "type_a" },
            { text: "更像B被拉偏位置变了", value: "type_b" },
            { text: "两种都有", value: "both_types" },
            { text: "都不明显", value: "neither" }
        ]
    },
    {
        id: 8,
        title: "你是否长期有一侧咀嚼更多、咬得更用力？",
        observation: "不是偶尔，而是长期形成习惯。比如总爱用同一边吃东西，一边咬更顺手，一边更容易累或更容易发达。",
        options: [
            { text: "经常", value: "often_chew" },
            { text: "偶尔", value: "sometimes_chew" },
            { text: "没有", value: "never_chew" },
            { text: "不确定", value: "uncertain_chew" }
        ]
    },
    {
        id: 9,
        title: "你是否感觉一侧表情启动更慢、控制更差？",
        observation: "重点看微笑时一侧慢半拍，鼓气一侧更容易漏，闭眼一侧更不全，说话时口角更偏一边。",
        options: [
            { text: "明显有", value: "obvious_control" },
            { text: "轻微有", value: "slight_control" },
            { text: "没有", value: "no_control" },
            { text: "不确定", value: "uncertain_control" }
        ]
    },
    {
        id: 10,
        title: "你是否长期固定同一侧侧睡、托腮或歪头？",
        observation: "只算长期固定习惯，不算偶尔，包括固定侧睡、固定单手托腮、长时间一边看手机、总把头偏向一边。",
        options: [
            { text: "经常", value: "often_posture" },
            { text: "偶尔", value: "sometimes_posture" },
            { text: "没有", value: "never_posture" },
            { text: "不确定", value: "uncertain_posture" }
        ]
    },
    {
        id: 11,
        title: "你是否明显有高低肩、歪脖子或一侧颈部总更紧？",
        observation: "看正面或照镜子，重点看肩膀是否一高一低，头是否总偏向一边，一侧颈侧是否总更紧更短，感觉脸像被脖子和肩膀带偏。",
        options: [
            { text: "明显有", value: "obvious_posture_issue" },
            { text: "偶尔有", value: "sometimes_posture_issue" },
            { text: "没有", value: "no_posture_issue" },
            { text: "不确定", value: "uncertain_posture_issue" }
        ]
    },
    {
        id: 12,
        title: "你是否有旧伤史、正畸史，或咬合/下巴轨迹长期不顺？",
        observation: "这里不是让用户自我诊断，只看是否有这些背景：正在或曾经正畸，下颌面部颈肩外伤史，张口或闭口轨迹长期不顺，咬合总觉得偏一边。",
        options: [
            { text: "明显有", value: "obvious_history" },
            { text: "有一点或不太确定", value: "slight_history" },
            { text: "没有", value: "no_history" },
            { text: "不确定", value: "uncertain_history" }
        ]
    }
];

// 导出题库
if (typeof module !== 'undefined' && module.exports) {
    module.exports = questions;
}